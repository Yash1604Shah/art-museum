let scene, camera, renderer, controls;

function init() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x000000);

  camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.set(0, 2, 10);

  renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  // Ambient Light
  const ambient = new THREE.AmbientLight(0xffffff, 1);
  scene.add(ambient);

  // Floor
  const floorTexture = new THREE.TextureLoader().load("https://cdn.pixabay.com/photo/2020/01/17/17/28/floor-4772000_1280.jpg");
  floorTexture.wrapS = floorTexture.wrapT = THREE.RepeatWrapping;
  floorTexture.repeat.set(40, 40);
  const floorMaterial = new THREE.MeshStandardMaterial({ map: floorTexture });
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), floorMaterial);
  floor.rotation.x = -Math.PI / 2;
  scene.add(floor);

  // Wall
  const wallMaterial = new THREE.MeshStandardMaterial({ color: 0x222222 });
  const wall = new THREE.Mesh(new THREE.BoxGeometry(50, 10, 1), wallMaterial);
  wall.position.set(0, 5, -20);
  scene.add(wall);

  // Frame
  const frameTexture = new THREE.TextureLoader().load("https://cdn.pixabay.com/photo/2018/07/10/19/45/frame-3526843_1280.png");
  const frame = new THREE.Mesh(new THREE.PlaneGeometry(3, 3), new THREE.MeshBasicMaterial({ map: frameTexture, transparent: true }));
  frame.position.set(0, 4, -19.4);
  scene.add(frame);

  // Bench
  const benchMaterial = new THREE.MeshStandardMaterial({ color: 0x8b4513 });
  const bench = new THREE.Mesh(new THREE.BoxGeometry(2, 0.3, 0.5), benchMaterial);
  bench.position.set(0, 0.15, -5);
  scene.add(bench);

  // OrbitControls
  controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.target.set(0, 2, 0);
  controls.update();

  animate();
}

function animate() {
  requestAnimationFrame(animate);
  controls.update();
  renderer.render(scene, camera);
}

window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

init();
